# Vincent's misc R functions

## Description

Handy functions to be used across projects. Most functions are undocumented and many are untested. Use with caution obviously.

## Installation

``` R
# install.packages("devtools") # Install if missing.
devtools::install_github("vsbpan/vmisc", dependencies = TRUE, force = TRUE)
```
